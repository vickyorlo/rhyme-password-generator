To run this code:

You must have Anaconda installed. 
In a terminal window, run the following commands:

$ conda env create --file environment.yaml
$ source activate neuralnetwork

To open the GUI app, run the following command:

$ python ./rhyming-passphrase-generator/gui.py

To generate rhymes for a file of words, run the following command:

$ python ./rhyming-passphrase-generator/tools.py -m model.h5

The file with input words is located in ./rhyming-passphrase-generator/to_predict.txt, while the resulting rhymes are written to the file ./rhyming-passphrase-generator/gui/predicted.txt.